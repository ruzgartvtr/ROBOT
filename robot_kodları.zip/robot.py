import os, threading, urllib.parse, webbrowser, speech_recognition as sr, requests, tempfile, subprocess, json
from elevenlabs.client import ElevenLabs
from kivy.app import App
from kivy.uix.image import Image
from kivy.uix.label import Label
from kivy.uix.floatlayout import FloatLayout
from kivy.core.window import Window
from kivy.clock import Clock

# 🔐 API Anahtarları
GEMINI_API_KEY = "AIzaSyAxw3BiBVE-6HPparnDQJK7bEsUhJg6bhg"
VOICE_ID = "rDol2Ljxrvb0kzLzHooJ"
ELEVEN_API_KEY = "sk_ffde8aed6e2dca9ded66ae1e071a7f142247fa419dbc4d03"
GOZ_DOSYASI = "robot_goz.png"

client = ElevenLabs(api_key=ELEVEN_API_KEY)
Window.clearcolor = (0.05, 0.05, 0.05, 1)

aktif = False
konusuyor_mu = False
gecmis_mesajlar = []
robot_app_instance = None

def ekrana_yaz(yazi):
    if robot_app_instance:
        robot_app_instance.set_text(yazi)

def seslendir(ses):
    global konusuyor_mu
    if ses.strip():
        print("[Robot]:", ses)
        ekrana_yaz(ses)
        try:
            konusuyor_mu = True
            audio_gen = client.text_to_speech.convert(
                text=ses,
                voice_id=VOICE_ID,
                model_id="eleven_multilingual_v2",
                output_format="mp3_44100_128"
            )
            audio_bytes = b"".join(audio_gen)
            with tempfile.NamedTemporaryFile(delete=False, suffix=".mp3") as tmp:
                tmp.write(audio_bytes)
                tmp_path = tmp.name
            subprocess.run(["ffplay", "-nodisp", "-autoexit", tmp_path],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception as e:
            print("[Seslendirme Hatası]:", e)
        finally:
            konusuyor_mu = False

def yapay_zeka_cevapla(yeni_mesaj):
    try:
        eski = "\n".join(gecmis_mesajlar[-5:])
        mesaj = f"Merhaba. Eski Mesajlar Bu: {eski}. Ve en yeni mesaj bu: {yeni_mesaj}. Ona göre cevap verebilir misin. Lütfen bu mesaja tamam yazma."

        url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={GEMINI_API_KEY}"
        headers = {"Content-Type": "application/json"}
        data = {
            "contents": [
                {
                    "role": "user",
                    "parts": [{"text": mesaj}]
                }
            ]
        }

        response = requests.post(url, headers=headers, data=json.dumps(data))
        response.raise_for_status()
        result = response.json()
        return result["candidates"][0]["content"]["parts"][0]["text"]

    except Exception as e:
        print("[Gemini POST Hatası]:", e)
        return "Şu anda cevap veremiyorum."

def youtube_ilk_sonuclu_video_ara(aranan):
    try:
        sonuc = subprocess.check_output(
            ['yt-dlp', f'ytsearch1:{aranan}', '--get-id', '--skip-download'],
            stderr=subprocess.DEVNULL
        ).decode().strip()
        return f"https://www.youtube.com/watch?v={sonuc}"
    except Exception as e:
        print("[YouTube Hatası]:", e)
        return None

def spotify_ac(aranan):
    try:
        query = urllib.parse.quote(aranan)
        url = f"https://open.spotify.com/search/{query}"
        webbrowser.open(url)
    except Exception as e:
        print("[Spotify Hatası]:", e)

def google_ara(aranan):
    try:
        query = urllib.parse.quote(aranan)
        url = f"https://www.google.com/search?q={query}"
        webbrowser.open(url)
    except Exception as e:
        print(f"[Google Hatası]: {e}")

def komut_coz(metin):
    global aktif
    komut = metin.lower().strip()
    print("[KOMUT]:", komut)
    if not komut or komut in ["robot", "robot dur"]:
        return

    if "robot dur" in komut:
        aktif = False
        seslendir("Bekleme moduna geçtim.")
        return

    if "çal" in komut:
        sarki = komut.replace("çal", "").strip()
        if sarki:
            spotify_ac(sarki)
            seslendir(f"{sarki} Spotify'da çalınıyor.")
        return

    if "aç" in komut:
        video = komut.replace("aç", "").strip()
        if video:
            link = youtube_ilk_sonuclu_video_ara(video)
            if link:
                webbrowser.open(link)
                seslendir(f"{video} YouTube'da açılıyor.")
            else:
                seslendir("Video bulunamadı.")
        return

    if "google" in komut:
        arama = komut.replace("google", "").strip()
        if arama:
            google_ara(arama)
        else:
            seslendir("Aradığınız Bulunamadı")
        return

    # Buraya kadar özel komutlar
    gecmis_mesajlar.append(komut)
    yanit = yapay_zeka_cevapla(komut)
    if yanit and len(yanit) < 100:
        seslendir(yanit)
    elif yanit:
        ekrana_yaz(yanit)
        print("[AI]:", yanit)

def ses_dinle():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        ses = r.listen(source, phrase_time_limit=7)
    try:
        return r.recognize_google(ses, language="tr-TR")
    except:
        return ""

def robot_loop():
    global aktif
    while True:
        if konusuyor_mu:
            continue
        metin = ses_dinle().lower()
        if not aktif and "robot" in metin:
            aktif = True
            seslendir("Dinliyorum.")
        elif aktif:
            komut_coz(metin)

class RobotApp(App):
    def build(self):
        global robot_app_instance
        robot_app_instance = self

        self.layout = FloatLayout()
        self.img = Image(source=GOZ_DOSYASI, size_hint=(None, None), size=(300, 300),
                         pos_hint={"center_x": 0.5, "center_y": 0.6})
        self.label = Label(text="Merhaba!", size_hint=(1, 0.2), pos_hint={"center_x": 0.5, "y": 0},
                           font_size=20, color=(1,1,1,1))
        self.layout.add_widget(self.img)
        self.layout.add_widget(self.label)

        Clock.schedule_interval(self.kirp, 3)
        threading.Thread(target=robot_loop, daemon=True).start()
        return self.layout

    def set_text(self, yazi):
        self.label.text = yazi

    def kirp(self, dt):
        self.img.opacity = 0.3
        Clock.schedule_once(lambda dt: setattr(self.img, 'opacity', 1), 0.2)

if __name__ == "__main__":
    RobotApp().run()
